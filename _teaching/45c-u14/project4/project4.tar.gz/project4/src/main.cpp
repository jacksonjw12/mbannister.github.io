#include "GameView.hpp"

int main()
{
    // Create game_view
    GameView game_view;

    // Some variables
    bool quit = false;
    bool game_over = false;
    unsigned int last_update = 0;

    // Adding some example apples and a stationary snake
    std::vector<Cell> red_apples(1);
    red_apples[0] = {10, 10};
    game_view.red_apples() = red_apples;

    std::vector<Cell> yellow_apples(1);
    yellow_apples[0] = {30, 30};
    game_view.yellow_apples() = yellow_apples;

    std::vector<Cell> snake(5);
    snake = {{15,16}, {15,17}, {15,18}, {15,19}, {15,20}};
    game_view.snake() = snake;

    // Un-comment this line and see what happens.
    // game_view.game_over() = true;

    // Game loop
    while ( !quit )
    {
        // Process game events
        GameEvent e = game_view.get_event();
        switch (e)
        {
            // Missing events
            case GameEvent::Quit:
                quit = true;
                break;
            default:
                break;
        }

        // Update game state
        if (game_view.time() - last_update > 250 && !game_over)
        {
            // Missing update code
            last_update = game_view.time();
        }

        // The next command actually render the GameView to your screen.
        // You should not need to add additional calls to this method.
        game_view.render();
    }

    return 0;
}


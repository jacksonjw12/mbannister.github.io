// A example of working with arrays.

#include <iostream>

// When working with arrays I need to pass the size, as there is no way to in
// general get this information in the function call.
void print_array(int A[], int size);
void fill_array(int A[], int size, int value);
int sum(int A[], int size);

int main()
{
    int A[10] = {0};

    print_array(A, 10);
    fill_array(A, 10, 2);
    print_array(A, 10);
    std::cout << sum(A, 10) << std::endl;

    return 0;   
}


void print_array(int A[], int size)
{
    for (int i = 0; i < size; i++)
    {
        std::cout << A[i] << "  ";
    }
    std::cout << std::endl;
}

// Recall that arrays are not pass by copy, as they are basically just pointers
void fill_array(int A[], int size, int value)
{
    for (int i = 0; i < size; i++) A[i] = value;
}

int sum(int A[], int size)
{
    int sum = 0;
    for (int i = 0; i < size; i++)
    {
        sum += A[i];
    }
    return sum;
}


// Multiple returns using modern C++. Here we only work with returning
// pairs from functions. Loop up tuples to see how to return any number
// of values.
#include <utility> // This provides the pair class and helper functions
#include <iostream>
#include <string>


std::pair<int,int> sum_and_product(int a, int b)
{
    return std::make_pair(a+b, a*b);
}

int main()
{
    // Here I use auto to avoid typing a long type.
    auto ret1 = sum_and_product(7, 11);
    std::cout << ret1.first << " " << ret1.second << std::endl;

    // We can use ties to get a Python like behavior with multiple returns.
    int x = 0;
    int y = 0;
    std::tie(x,y) = sum_and_product(5, 8);
    std::cout << x << " " << y << std::endl;
    return 0;
}


#include "square.hpp"

int square(int n)
{
    return n*n;
}


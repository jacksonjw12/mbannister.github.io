#ifndef __SQUARE_HPP__
#define __SQUARE_HPP__

int square(int n);

#endif // __SQUARE_HPP__


// This is a simple example of separate compilation in C++.
// Pay attention to header guards, which prevent multiple inclusion,
// and the separation of declaration into header files and definitons
// into cpp files.
#include <iostream>
#include "square.hpp"
#include "cube.hpp"

int main()
{
    int n = 0;
    std::cout << "Please enter a number: ";
    std::cin >> n;
    std::cout << "The square of " << n << " is "
              << square(n) << std::endl; 
    std::cout << "The cube of " << n << " is  "
              << cube(n) << std::endl; 
    return 0;
}


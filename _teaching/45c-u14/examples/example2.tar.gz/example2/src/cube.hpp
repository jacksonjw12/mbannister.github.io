#ifndef __CUBE_HPP__
#define __CUBE_HPP__

#include "square.hpp"

int cube(int n);

#endif // __CUBE_HPP__


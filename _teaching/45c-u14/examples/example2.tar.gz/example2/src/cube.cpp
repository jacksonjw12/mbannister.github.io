#include "cube.hpp"

int cube(int n)
{
    return square(n) * n;
}


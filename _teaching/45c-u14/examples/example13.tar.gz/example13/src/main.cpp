// This example demonstrates the use of dynamic_cast to safely convert
// between object related by inheritance relationships.
#include <iostream>
#include <string>
#include <sstream>
#include "animals.hpp"

int main()
{
    Animal *animal1 = new Dog();
    Animal *animal2 = new Cat();

    // Here we cast to a more specific type to use features unique to that class.
    Dog *dog1 = dynamic_cast<Dog*>(animal1);
    dog1->bite();

    Cat *cat1 = dynamic_cast<Cat*>(animal2);
    cat1->scratch();

    // When doing an invalid cast a nullptr is returned.
    Dog *dog2 = dynamic_cast<Dog*>(animal2);
    if (dog2 == nullptr) std::cout << "animal2 is not a Dog" << std::endl;

    Cat *cat2 = dynamic_cast<Cat*>(animal1);
    if (cat2 == nullptr) std::cout << "animal1 is not a Cat" << std::endl;

    return 0;
}


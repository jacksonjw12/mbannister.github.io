
#include <iostream>
#include "animals.hpp"


//==============================================================================
Animal::Animal()
{
}

Animal::~Animal()
{
}


//==============================================================================
Dog::Dog()
{
}

Dog::~Dog()
{
}

void Dog::make_sound()
{
    std::cout << "Whuff Whuff" << std::endl;
}

void Dog::bite()
{
    std::cout << "Bite" << std::endl;
}


//==============================================================================
Cat::Cat()
{
}

Cat::~Cat()
{
}

void Cat::make_sound()
{
    std::cout << "Meow Meow" << std::endl;
}

void Cat::scratch()
{
    std::cout << "Scratch" << std::endl;
}


//==============================================================================
Mouse::Mouse()
{
}

Mouse::~Mouse()
{
}

void Mouse::make_sound()
{
    std::cout << "Squeak Squeak" << std::endl;
}



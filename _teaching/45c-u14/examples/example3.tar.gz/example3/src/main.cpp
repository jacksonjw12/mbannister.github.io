#include <iostream>
#include <string>

#include "point.hpp"

int main()
{
    Point p = {3, 7};
    Point q = {10, 16};

    // The following code will not compile (try it), as Pair and Point are
    // different types.
    // Pair r = {1,2};
    // Pair s = {5,6};
    // std::cout << distance_squared(r,s);

    std::cout << "p = " << p << std::endl;
    std::cout << "q = " << q << std::endl;

    std::cout << "The distance squared between p and q is "
              << distance_squared(p, q) << std::endl;
  
    return 0;
}


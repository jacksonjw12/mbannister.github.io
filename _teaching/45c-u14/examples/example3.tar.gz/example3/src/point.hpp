#ifndef __POINT_HPP__
#define __POINT_HPP__

#include <iostream>

struct Point
{
    int x;
    int y;
};

// Although Pair has the same form as Point it is a different type!
struct Pair
{
    int x;
    int y;
};

int distance_squared(Point p, Point q);
// The following function is used by C++ when we use 'std::cout <<'
std::ostream& operator<<(std::ostream& out, const Point& p);

#endif // __POINT_HPP__


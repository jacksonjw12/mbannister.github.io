#include "point.hpp"

int distance_squared(Point p, Point q)
{
    int delta_x = p.x - q.x;
    int delta_y = p.y - q.y; 
    return delta_x*delta_x + delta_y*delta_y;
}

std::ostream& operator<<(std::ostream& out, const Point& p)
{
    out << "(" << p.x << ", " << p.y << ")";
    return out;
}


// Example code from class on using the GUI interface for project 1.
// This code used the number keys 1,2,3,4 to move a square around the screen.

#include <iostream>
#include <cassert>
#include "GameView.hpp"

int main()
{
    // Create GameView object
    GameView view;

    // Game loop
    bool quit = false;
    int pos_x = 15;
    int pos_y = 15;
    while ( !quit )
    {
        // Switch to process game events.
        GameEvent e = view.get_event();

        switch ( e.type )
        {
            case EventType::Quit:
                quit = true;
                break;
            case EventType::Key:
                view.set_status(pos_x, pos_y, false);
                switch ( e.data1 )
                {
                    case 1:
                        pos_x--;
                        break;
                    case 2:
                        pos_y++;
                        break;
                    case 3:
                        pos_y--;
                        break;
                    case 4:
                        pos_x++;
                        break;
                    default:
                        assert(1 == 0);
                        
                }
                break;
            default:
                // Some events are not used in this code.
                break;
        }

        SDL_Delay(50); // Keeps the program from using 100% CPU

        view.set_status(pos_x, pos_y, true);
        view.update_status();

        // Render the game board.
        view.render();
    }

    return 0;
}


//==============================================================================
// DO NOT MODIFY THIS FILE
//
// This file contains the implementation of the GameView object. The GameView
// object acts as an interface between your code and the SDL GUI library.
//
#include <cassert>
#include "GameView.hpp"


//==private function declarations===============================================
namespace
{
    void draw_world(SDL_Renderer *renderer, SDL_Rect board, const World world);
    void handle_window_event(SDL_WindowEvent we, SDL_Rect &board);
    void handle_mouse_event(SDL_MouseButtonEvent me, SDL_Rect board, GameEvent &ge);
    void handle_key_event(SDL_KeyboardEvent se, GameEvent &ge);
    void clear_world(World &world);
}



//==default constructor=========================================================
GameView::GameView()
    : window(nullptr)
    , board{0,0,550,550}
    , renderer(nullptr)
    , world()
    , new_world()
{
    SDL_Init(SDL_INIT_VIDEO);
    // 
    // This code seems to cause problems in VirtualBox for some students.
    // SDL_CreateWindowAndRenderer(
    //        board.w, board.h, SDL_WINDOW_RESIZABLE, &window, &renderer);
    //
    window = SDL_CreateWindow(
            "Project 1", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
            board.w, board.h, SDL_WINDOW_RESIZABLE);
    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_SOFTWARE);
    
    clear_world(world);
    clear_world(new_world);
}



//==destructor==================================================================
GameView::~GameView()
{
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();
}



//==get_event===================================================================
GameEvent GameView::get_event()
{
    SDL_Event se;
    GameEvent ge = {EventType::Null, 0, 0};
    while ( SDL_PollEvent( &se ) )
    {
        switch ( se.type )
        {
            case SDL_QUIT:
                ge.type = EventType::Quit;
                break;
            case SDL_KEYDOWN:
                handle_key_event(se.key, ge);
                break;
            case SDL_MOUSEBUTTONDOWN:
                handle_mouse_event(se.button, board, ge);
                break;
            case SDL_WINDOWEVENT:
                handle_window_event(se.window, board);
                break;
        }
    }
    return ge;
}



//==render======================================================================
void GameView::render()
{
    SDL_SetRenderDrawColor(renderer, 128, 128, 128, 255);
    SDL_RenderClear(renderer);
    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
    SDL_RenderFillRect(renderer, &board);

    SDL_SetRenderDrawColor(renderer, 0, 255, 0, 255);
    draw_world(renderer, board, world);

    SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255);
    SDL_SetRenderDrawColor(renderer, 255, 255, 0, 255);
    SDL_SetRenderDrawColor(renderer, 0, 255, 0, 255);

    SDL_RenderPresent(renderer);
}



//==get_status==================================================================
bool GameView::get_status(int i, int j)
{
    assert(0 <= i && i < WORLD_SIZE);
    assert(0 <= j && j < WORLD_SIZE);
    return world[i][j];
}



//==set_status==================================================================
void GameView::set_status(int i, int j, bool status)
{
    assert(0 <= i && i < WORLD_SIZE);
    assert(0 <= j && j < WORLD_SIZE);
    new_world[i][j] = status;
}



//==update_status===============================================================
void GameView::update_status()
{
    for (int i = 0; i < WORLD_SIZE; i++)
    {
        for (int j = 0; j < WORLD_SIZE; j++)
        {
            world[i][j] = new_world[i][j];
        }
    }
}



//==clear=======================================================================
void GameView::clear()
{
    clear_world(world);
}


//==============================================================================
void GameView::load_board(int n)
{
    clear_world(world);
    switch ( n )
    {
        case 1:
            world[2][5] = true;
            world[3][5] = true;
            world[4][5] = true;
            world[4][4] = true;
            world[3][3] = true;
            break;
        case 2:
            world[5][20] = true;
            world[6][20] = true;
            world[7][20] = true;

            world[25][20] = true;
            world[26][20] = true;
            world[27][20] = true;
            world[24][19] = true;
            world[25][19] = true;
            world[26][19] = true;

            world[35][35] = true;
            world[36][35] = true;
            world[35][36] = true;
            world[36][36] = true;
            world[37][37] = true;
            world[38][37] = true;
            world[37][38] = true;
            world[38][38] = true;
            break;
        case 3:
            world[5][25] = true;
            world[6][25] = true;
            world[7][25] = true;
            world[8][25] = true;
            world[8][26] = true;
            world[8][27] = true;
            world[4][26] = true;
            world[7][28] = true;
            world[4][28] = true;
            break;
        default:
            // Just clear
            break;
    }
}

//==private function definitions================================================
namespace
{

void clear_world(World &world)
{
    for (int i = 0; i < WORLD_SIZE; i++)
    {
        for (int j = 0; j < WORLD_SIZE; j++)
        {
            world[i][j] = false;
        }
    }
}

void draw_world(SDL_Renderer *renderer, SDL_Rect board, const World world)
{
    SDL_Rect rects[WORLD_SIZE * WORLD_SIZE];
    int cell_size = board.w / WORLD_SIZE;
    int cell_number = 0;
    for (int i = 0; i < WORLD_SIZE; i++)
    {
        for (int j = 0; j < WORLD_SIZE; j++)
        {
            if (world[i][j] == true)
            {
                rects[cell_number] = {board.x + cell_size * i + 1,
                                      board.y + cell_size * j + 1,
                                      cell_size - 2,
                                      cell_size - 2};
                cell_number++;
            }
        }
    }
    SDL_RenderFillRects(renderer, rects, cell_number);
}

void handle_window_event(SDL_WindowEvent we, SDL_Rect &board)
{
    switch ( we.event )
    {
        case SDL_WINDOWEVENT_SIZE_CHANGED:
            int width = we.data1;
            int height = we.data2;
            int board_size =
                (std::min(width, height) / WORLD_SIZE) * WORLD_SIZE;
            board = {std::max(0, (width - board_size) / 2),
                     std::max(0, (height - board_size) / 2),
                     board_size,
                     board_size};
            break;
    }
}

void handle_mouse_event(SDL_MouseButtonEvent me, SDL_Rect board, GameEvent &ge)
{
    ge.type = EventType::Click;
    switch ( me.button )
    {
        case SDL_BUTTON_LEFT:
            int cell_size = board.w / WORLD_SIZE;
            ge.data1 = (me.x - 1 - board.x) / cell_size;
            ge.data2 = (me.y - 1 - board.y) / cell_size;
            break;
    }
}

void handle_key_event(SDL_KeyboardEvent ke, GameEvent &ge)
{
    ge.type = EventType::Key;
    switch ( ke.keysym.sym )
    {
        ge.type = EventType::Key;
        case SDLK_1:
            ge.data1 = 1;
            break;
        case SDLK_2:
            ge.data1 = 2;
            break;
        case SDLK_3:
            ge.data1 = 3;
            break;
        case SDLK_4:
            ge.data1 = 4;
            break;
        case SDLK_SPACE:
            ge.type = EventType::Pause;
            break;
        case SDLK_q:
            ge.type = EventType::Quit;
            break;
        default:
            ge.type = EventType::Null;
    }
}

} // namespace


// This example demonstrates a style of passing array arguments, where we
// pass a pointer to the start of the array and a pointer just past the end
// of the array. This style is motivated by the way the STL handles arrays
// and array like objects.
#include <iostream>
#include <string>

void array_print(int *begin, int *end);
double array_mean(int *begin, int *end);
int array_max(int *begin, int *end);

int main()
{
    // Allocate array
    int size = 10;
    int *array = new int[size];

    // Fill the array with some numbers
    array[0] = 7;
    for (int i = 1; i < size; i++) array[i] = (17 * array[i-1] + 23) % 11;

    // Print array
    std::cout << "array = ";
    array_print(array, array+size);
    std::cout << std::endl;

    // Print max
    std::cout << "max(array) = "
              << array_max(array, array+size)
              << std::endl;

    // Print mean
    std::cout << "mean(array)  = "
              << array_mean(array, array+size)
              << std::endl;

    delete[] array;

    return 0;
}

void array_print(int *begin, int *end)
{
    for (int *current = begin; current != end; current++)
    {
        std::cout << *current << " ";
    }
}

double array_mean(int *begin, int *end)
{
    int sum = 0;
    for (int *current = begin; current != end; current++) sum += *current;
    // Here we cast the int sum to a double using static_cast
    return static_cast<double>(sum) / (end - begin);
}

int array_max(int *begin, int *end)
{
    int max = *begin;
    for (int *current = begin; current != end; current++)
    {
        if (*current > max) max = *current;
    }
    return max;
}


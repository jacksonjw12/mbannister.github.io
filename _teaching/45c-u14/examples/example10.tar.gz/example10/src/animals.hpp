#ifndef __ANIMALS_HPP__
#define __ANIMALS_HPP__

class Animal
{
    public:
        Animal();
        virtual ~Animal();
        virtual void make_sound() = 0;
};

class Dog : public Animal
{
    public:
        Dog();
        virtual ~Dog();
        virtual void make_sound();
};

class Cat : public Animal
{
    public:
        Cat();
        virtual ~Cat();
        virtual void make_sound();
};

class Mouse : public Animal
{
    public:
        Mouse();
        virtual ~Mouse();
        virtual void make_sound();
};

#endif // __ANIMALS_HPP__

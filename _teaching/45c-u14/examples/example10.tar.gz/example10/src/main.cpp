// Array of animals example from class. Now with file parsing.
// To run the program type:
//     make memcheck < data/input.dat
#include <iostream>
#include <string>
#include <sstream>
#include "animals.hpp"

int main()
{
    // Parse file and create array of animals
    std::string line;

    std::getline(std::cin, line);
    std::stringstream line_stream(line);

    int count = 0;
    line_stream >> count;

    Animal **animals = new Animal*[count];

    for (int i = 0; i < count; i++)
    {
        std::getline(std::cin, line);
        if (line == "DOG")
        {
            animals[i] = new Dog();
        }
        else if (line == "CAT")
        {
            animals[i] = new Cat();
        }
        else if (line == "MOUSE")
        {
            animals[i] = new Mouse();
        }
        else
        {
            std::cerr << "Bad line" << std::endl;
        }
    }

    // Make the animals make sound
    for (int i = 0; i < count; i++)
    {
        animals[i]->make_sound();
    }

    // Clean up the heap
    for (int i = 0; i < count; i++)
    {
        delete animals[i];
        animals[i] = nullptr;
    }

    delete[] animals;

    return 0;
}


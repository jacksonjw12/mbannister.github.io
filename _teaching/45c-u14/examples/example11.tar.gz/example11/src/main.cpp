#include <iostream>
#include "ArrayList.hpp"

void print_array_list(const ArrayList &list);

int main()
{
    ArrayList list1;
    list1.push_back("A")
         .push_back("B")
         .push_back("C")
         .push_back("D")
         .push_back("E")
         .push_back("F")
         .push_back("G")
         .push_back("H")
         .push_back("I")
         .push_back("J")
         .push_back("K")
         .push_back("L")
         .push_back("M")
         .push_back("N")
         .push_back("O")
         .push_back("P")
         .push_back("Q")
         .push_back("R")
         .push_back("S")
         .push_back("T");

    ArrayList list2 = list1;
    list2.at(3) = "Z";

    print_array_list(list1);
    print_array_list(list2);

    return 0;
}



void print_array_list(const ArrayList &list)
{
    for (int i = 0; i < list.size() - 1; i++)
    {
        std::cout << list.at(i) << " - ";
    }
    if (list.size() > 1)
    {
        std::cout << list.at(list.size()-1);
    }
    std::cout << std::endl;
}



// This file contains some examples of writing template functions.
#include <iostream>
#include <string>
#include "array.hpp"

int main()
{
    const int size = 5;
    int A[size] = {9,3,5,1,8};
    long int B[size] = {1,4,8,3,2};
    double C[size] = {1.3,4.6,8.2,3.1,2.8};
    std::string D[size] = {"1.3","4.6","8.2","3.1","2.8"};

    std::cout << "A = ";
    print_array(A, A+size);
    std::cout << "mean(A) = " << mean(A, A+size) << std::endl;
    std::cout << "B = ";
    print_array(B, B+size);
    std::cout << "mean(B) = " << mean(B, B+size) << std::endl;
    std::cout << "C = ";
    print_array(C, C+size);
    std::cout << "mean(C) = " << mean(C, C+size) << std::endl;
    std::cout << "D = ";
    print_array(D, D+size);
    std::cout << "mean(D) = " << mean(D, D+size) << std::endl;
    return 0;
}


// This file contains template methods. The entire implementation is
// contained in the header file, as this is required for templates.

// This template function will print any array, as long as the elements
// of the array can be printed.
template <typename T>
void print_array(T* begin, T* end)
{
    for (T* current = begin; current != end; current++)
    {
        std::cout << *current << " ";
    }
    std::cout << std::endl;
}

// This computes the mean of an array, as long as the elements are a
// numeric type.
template <typename T>
double mean(T* begin, T* end)
{
    T sum = 0;
    for (T *current = begin; current != end; current++)
    {
        sum += *current;
    }
    return static_cast<double>(sum) / (end - begin);
}

// This function is a specialization of the mean function, specifically
// for arrays of strings. Here we assume the string represent doubles.
template <>
double mean(std::string* begin, std::string* end)
{
    double sum = 0;
    for (std::string *current = begin; current != end; current++)
    {
        sum += std::stod(*current);
    }
    return sum / (end - begin);
}


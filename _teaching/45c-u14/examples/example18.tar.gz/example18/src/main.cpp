// Simple example of using bitwise operations in C++
#include <iostream>
#include <bitset>

void bit_print(uint16_t num);


int main()
{
    uint16_t n = 12345;
    uint16_t m = 7112;

    std::cout << "n = ";
    bit_print(n);
    std::cout << std::endl;
    std::cout << "m = ";
    bit_print(m);
    std::cout << std::endl;
    std::cout << "n | m = ";
    bit_print(n | m);
    std::cout << std::endl;
    std::cout << "n & m = ";
    bit_print(n & m);
    std::cout << std::endl;
    std::cout << "n ^ m = ";
    bit_print(n ^ m);
    std::cout << std::endl;
    std::cout << "~n = ";
    bit_print(~n);
    std::cout << std::endl;
    std::cout << "~m = ";
    bit_print(~m);
    std::cout << std::endl;
    std::cout << "n << 3 = ";
    bit_print(n << 3);
    std::cout << std::endl;
    std::cout << "m << 10 = ";
    bit_print(m << 10);
    std::cout << std::endl;
    std::cout << "n >> 5 = ";
    bit_print(n >> 5);
    std::cout << std::endl;
    std::cout << "m >> 8 = ";
    bit_print(m >> 8);
    std::cout << std::endl;

    return 0;
}



void bit_print(uint16_t num)
{
    std::bitset<16> bs(num);
    for (int i = 15; i >=0; i--)
    {
        std::cout << bs[i];
        if (i % 4 == 0) std::cout << " ";
    }
    std::cout << std::endl;
}


// This example show the basic usage of pointers and references.

#include <iostream>

void add(int a, int b, int &sum); // returns by reference
void multiply(int a, int b, int *product); // returns by pointer

int main()
{
    // Create some integer variables
    int a = 1;
    int b = 2;
    int &c = a; // c is now an alias for a
    // Create some pointer (to integers) variables
    int *p = nullptr;
    int *q = nullptr;

    p = &a;
    q = &b;

    c = 5; // Changes a to 5
    std::cout << "a = " << a << std::endl << std::endl;

    // Why do the first two change every run?
    std::cout << "p = " << p << std::endl;
    std::cout << "q = " << q << std::endl;
    std::cout << "*p = " << *p << std::endl;
    std::cout << "*q = " << *q << std::endl << std::endl;

    // Let's modify a variable via a pointer
    *p = 7;
    *q = 93;
    std::cout << "a = " << a << std::endl;
    std::cout << "b = " << b << std::endl;

    // Returning by pointer and by reference
    int sum = 0;
    add(a,b,sum);
    std::cout << "a + b = " << sum << std::endl;
    int product = 0;
    multiply(a,b,&product);
    std::cout << "a * b = " << product << std::endl;

    return 0;
}

void add(int a, int b, int &sum)
{
    sum = a + b;
}

void multiply(int a, int b, int *product)
{
    *product = a * b;
}

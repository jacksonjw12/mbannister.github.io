#include <iostream>
#include "ArrayList.hpp"

int main()
{
    ArrayList list1;
    list1.push_back("A")
         .push_back("B")
         .push_back("C")
         .push_back("D")
         .push_back("E")
         .push_back("F")
         .push_back("G")
         .push_back("H")
         .push_back("I")
         .push_back("J")
         .push_back("K")
         .push_back("L")
         .push_back("M")
         .push_back("N")
         .push_back("O")
         .push_back("P")
         .push_back("Q")
         .push_back("R")
         .push_back("S")
         .push_back("T");

    ArrayList list2 = list1;
    list2.at(3) = "Z";


    for (auto e : list1) std::cout << e << "  ";
    std::cout << std::endl;
    for (auto e : list2) std::cout << e << "  ";

    std::cout << std::endl;

    return 0;
}


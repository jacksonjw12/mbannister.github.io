#include <cassert>
#include "ArrayList.hpp"

// Private functions
namespace
{
    unsigned int const START_SIZE = 16;
    void array_copy(std::string *source, std::string *dest, unsigned int size)
    {
        for (int i = 0; i < size; i++) dest[i] = source[i];
    }
}


ArrayList::ArrayList()
    : m_data(nullptr)
    , m_size(0)
    , m_capacity(0)
{
    m_data = new std::string[START_SIZE];
    m_capacity = START_SIZE;
}

ArrayList::ArrayList(unsigned int capacity)
    : m_data(nullptr)
    , m_size(0)
    , m_capacity(capacity)
{
    m_data = new std::string[m_capacity];
}

ArrayList::ArrayList(const ArrayList& other) // Copy constructor
    : m_data(nullptr)
    , m_size(other.m_size)
    , m_capacity(other.m_capacity)
{
    m_data = new std::string[m_capacity];
    array_copy(other.m_data, m_data, m_capacity);
}

ArrayList::~ArrayList()
{
    delete[] m_data;
}


ArrayList& ArrayList::operator=(const ArrayList& other)
{
    if (this != &other)
    {
        delete[] m_data;
        m_size = other.m_size;
        m_capacity = other.m_capacity;

        m_data = new std::string[m_capacity];
        array_copy(other.m_data, m_data, m_size);
    }
    return *this;
}

std::string& ArrayList::at(unsigned int index)
{
    assert(0 <= index && index < m_size);
    return m_data[index];
}



const std::string& ArrayList::at(unsigned int index) const
{
    assert(0 <= index && index < m_size);
    return m_data[index];
}


ArrayList& ArrayList::push_back(std::string input)
{
    assert(m_size <= m_capacity);
    if (m_size == m_capacity)
    {
        m_capacity *= 2;
        std::string *new_data = new std::string[m_capacity];
        array_copy(m_data, new_data, m_size);
        delete[] m_data;
        m_data = new_data;
        new_data = nullptr;
    }
    m_data[m_size] = input;
    m_size++;
    return *this;
}

unsigned int ArrayList::size() const
{
    return m_size;
}

unsigned int ArrayList::capacity() const
{
    return m_capacity;
}

ArrayList::It ArrayList::begin()
{
    return ArrayList::It(this, 0);
}

ArrayList::It ArrayList::end()
{
    return ArrayList::It(this, m_size);
}




//==============================================================================
// Implementation of ArrayList::It
//==============================================================================
ArrayList::It::It(ArrayList* list, int current)
    : m_list(list)
    , m_current(current)
{
}

ArrayList::It::~It()
{
}

std::string& ArrayList::It::operator*()
{
    return m_list->at(m_current);
}

std::string* ArrayList::It::operator->()
{
    return &(m_list->at(m_current));
}

ArrayList::It& ArrayList::It::operator++()
{
    m_current++;
    return *this;
}

ArrayList::It ArrayList::It::operator++(int)
{
    ArrayList::It old = *this;
    m_current++;
    return old;
}

bool ArrayList::It::operator==(const ArrayList::It& other)
{
    return (m_list == other.m_list)
        && (m_current == other.m_current);
}

bool ArrayList::It::operator!=(const ArrayList::It& other)
{
    return !operator==(other);
}


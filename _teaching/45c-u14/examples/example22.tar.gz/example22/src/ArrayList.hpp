#ifndef __ARRAYLIST_HPP__
#define __ARRAYLIST_HPP__

#include <string>

class ArrayList
{
    public:
        ArrayList();
        ArrayList(unsigned int capacity);
        ArrayList(const ArrayList& other); // Copy constructor
        ArrayList& operator=(const ArrayList& other);
        ~ArrayList();
        std::string& at(unsigned int index);
        const std::string& at(unsigned int index) const;
        ArrayList& push_back(std::string input);
        unsigned int size() const;
        unsigned int capacity() const;

        class It;
        ArrayList::It begin();
        ArrayList::It end();
    private:
        std::string *m_data;
        unsigned int m_size;
        unsigned int m_capacity;
};

class ArrayList::It
{
    public:
        It(ArrayList* list, int current);
        ~It();

        // This is the minimal set of operators that should be overloaded
        // for a class to behave as an iterator.
        std::string& operator*();
        std::string* operator->();
        ArrayList::It& operator++();
        ArrayList::It operator++(int);
        bool operator==(const ArrayList::It& other);
        bool operator!=(const ArrayList::It& other);

    private:
        ArrayList *m_list;
        int m_current;
};

#endif

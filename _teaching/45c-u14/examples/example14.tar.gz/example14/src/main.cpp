// This examples shows some of the fundamental data structure in the STL
// and how to work with them using the new for-each loop in C++
#include <iostream>
#include <string>
#include <array> // Provides fixed size array
#include <vector> // Provides a resizable array
#include <unordered_map> // Provides a dictionary data structure

int main()
{
    // Creates a fixed size array, and then uses for-each loops to fill
    // the array and then print the array. Note, the writing for-each loop
    // uses reference so that we can change the elements of the array in the
    // loop.
    std::array<int, 5> my_array;
    for (auto& e : my_array)
    {
        e = 2;
    }
    for (auto e : my_array)
    {
        std::cout << e << " ";
    }
    std::cout << std::endl << std::endl;

    // We can use the "using" keyword to make aliases for complicated types
    using Matrix = std::array<std::array<int,5>,5>;
    Matrix my_matrix;
    int i = 0;
    for (auto& c : my_matrix)
    {
        for (auto& e : c)
        {
            e = i;
            i++;
        }
    }
    for (auto c : my_matrix)
    {
        for (auto e : c)
        {
            if (e < 10) std::cout << " ";
            std::cout << e << " ";
        }
        std::cout << std::endl;
    }
    std::cout << std::endl;

    // The vector type provides a resizable array, and should normally
    // be your default container in C++.
    std::vector<int> my_vector;
    int j = 11;
    for (int i = 0; i < 10; i++)
    {
        my_vector.push_back(j);
        j = (j*j) % 23;
    }
    for (auto e : my_vector)
    {
        std::cout << e << " ";
    }
    std::cout << std::endl << std::endl;

    // Finally we have a unordered_map, which acts like the dictionary
    // in Python. Just like in python the keys are unordered when we
    // iterate through the key value pairs.
    std::unordered_map<int,std::string> my_map;
    my_map[3] = "World";
    my_map[-1] = "Hell0";
    my_map[100] = "!!!";
    for (auto e : my_map)
    {
        std::cout << "key = " << e.first << "  :  value = " << e.second;
        std::cout << std::endl;
    }
    std::cout << std::endl;

    return 0;
}


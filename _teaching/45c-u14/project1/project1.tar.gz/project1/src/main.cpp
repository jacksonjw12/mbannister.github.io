#include <iostream>
#include "GameView.hpp"

int main()
{
    // Create GameView object
    GameView view;

    // Some variables for animation timing
    bool pause = true;
    unsigned int last_update = 0;

    // Game loop
    bool quit = false;
    while ( !quit )
    {
        // Switch to process game events.
        GameEvent e = view.get_event();
        e = e; // TODO: Remove this line

        //
        // TODO: Add switch statement to process events.
        //

        // Handle update every quarter second.
        if (SDL_GetTicks() - last_update > 250 && pause == false)
        {
            //
            // TODO: Add code to update board to next generation
            //

            last_update = SDL_GetTicks();
        }
        SDL_Delay(50); // Keeps the program from using 100% CPU.

        // Render the game board.
        view.render();
    }

    return 0;
}


//==============================================================================
// DO NOT MODIFY THIS FILE
//
// This is the header file for the GameView object.
//
#ifndef __GAMEVIEW_HPP__
#define __GAMEVIEW_HPP__
#include <array>
#include <SDL.h>

enum class EventType {Null, Quit, Pause, Click, Key};
struct GameEvent
{
    EventType type;
    unsigned int data1;
    unsigned int data2;
};

const int WORLD_SIZE = 50;
using World = std::array<std::array<bool,WORLD_SIZE>, WORLD_SIZE>;


class GameView {
    
    public:
        GameView();
        ~GameView();
        GameView(const GameView&) = delete;
        GameView& operator=(const GameView&) = delete;
        GameEvent get_event();
        void render();
        bool get_status(int i, int j);
        void set_status(int i, int j, bool status);
        void load_board(int n);
        void clear();
        void update_status();
    
    private:
        SDL_Window *window;
        SDL_Rect board;
        SDL_Renderer *renderer;
        World world;
        World new_world;
};

#endif


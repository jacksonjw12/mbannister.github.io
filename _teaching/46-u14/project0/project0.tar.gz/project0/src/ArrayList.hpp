#ifndef __ARRAYLIST_HPP__
#define __ARRAYLIST_HPP__

#include <string>

class ArrayList
{
    public:
        ArrayList();
        ArrayList(unsigned int capacity);
        ArrayList(const ArrayList& other);
        ArrayList& operator=(const ArrayList& other);
        ~ArrayList();
        std::string& at(unsigned int index);
        const std::string& at(unsigned int index) const;
        ArrayList& push_back(std::string input);
        unsigned int size() const;
        unsigned int capacity() const;

    private:
        std::string *m_data;
        unsigned int m_size;
        unsigned int m_capacity;
};
    
#endif

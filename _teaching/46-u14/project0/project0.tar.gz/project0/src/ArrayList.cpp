#include <cassert>
#include "ArrayList.hpp"

// Private functions in an un-named namespace
namespace
{
    unsigned int const START_SIZE = 16;
    void array_copy(std::string *source, std::string *dest, unsigned int size)
    {
        for (int i = 0; i < size; i++) dest[i] = source[i];
    }
}



ArrayList::ArrayList()
    : m_data(nullptr)
    , m_size(0)
    , m_capacity(0)
{
    m_data = new std::string[START_SIZE];
    m_capacity = START_SIZE;
}

ArrayList::ArrayList(unsigned int capacity)
    : m_data(nullptr)
    , m_size(0)
    , m_capacity(capacity)
{
    m_data = new std::string[m_capacity];
}

ArrayList::ArrayList(const ArrayList& other)
    : m_data(nullptr)
    , m_size(other.m_size)
    , m_capacity(other.m_capacity)
{
    m_data = new std::string[m_capacity];
    array_copy(other.m_data, m_data, m_capacity);
}

ArrayList::~ArrayList()
{
    delete[] m_data;
}

ArrayList& ArrayList::operator=(const ArrayList& other)
{
    if (this != &other)
    {
        delete[] m_data;
        m_size = other.m_size;
        m_capacity = other.m_capacity;

        m_data = new std::string[m_capacity];
        array_copy(other.m_data, m_data, m_size);
    }
    return *this;
}

std::string& ArrayList::at(unsigned int index)
{
    assert(index < m_size);
    return m_data[index];
}

const std::string& ArrayList::at(unsigned int index) const
{
    assert(index < m_size);
    return m_data[index];
}

ArrayList& ArrayList::push_back(std::string input)
{
    assert(m_size <= m_capacity);
    if (m_size == m_capacity)
    {
        m_capacity *= 2;
        std::string *new_data = new std::string[m_capacity];
        array_copy(m_data, new_data, m_size);
        delete[] m_data;
        m_data = new_data;
        new_data = nullptr;
    }
    m_data[m_size] = input;
    m_size++;
    return *this;
}

unsigned int ArrayList::size() const
{
    return m_size;
}

unsigned int ArrayList::capacity() const
{
    return m_capacity;
}


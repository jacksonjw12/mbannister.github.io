#include <cassert>
#include <iostream>

#include "Queue.hpp"

int main()
{
    std::cout << "Testing queue: " << std::endl;
    Queue myQueue(4);
    myQueue.push(5);
    myQueue.push(3);
    myQueue.push(7);
    myQueue.push(0);
    myQueue.push(-4); // This should cause the queue to resize
    assert(myQueue.size() == 5);
    assert(myQueue.capacity() == 8);
    myQueue.push(-2);
    myQueue.push(5);
    myQueue.push(7);
    
    std::cout << "Expect: 5, 3, 7" << std::endl;
    std::cout << "   Got: " << myQueue.peek() << ", ";
    myQueue.pop();
    std::cout << myQueue.peek() << ", ";
    myQueue.pop();
    std::cout << myQueue.peek() << std::endl;
    myQueue.pop();
    
    myQueue.push(4); // Should not cause resize
    myQueue.push(5);
    assert(myQueue.capacity() == 8);
    myQueue.push(6);
    myQueue.push(9);
    assert(myQueue.capacity() == 16);
    
    Queue myQueue2(myQueue); // Testing copy constructor
    Queue myQueue3;
    myQueue3 = myQueue; // Testing copy assignment
    
    std::cout << "Expect: 0, -4, -2, 5, 7, 4, 5, 6, 9" << std::endl;
    std::cout << "   Got: ";
    while (myQueue.size() > 1)
    {
        std::cout << myQueue.peek() << ", ";
        myQueue.pop();
    }
    std::cout << myQueue.peek() << std::endl;
    myQueue.pop();
    
    std::cout << std::endl << "Testing copy constructor: " << std::endl;
    std::cout << "Expect: 0, -4, -2, 5, 7, 4, 5, 6, 9" << std::endl;
    std::cout << "   Got: ";
    while (myQueue2.size() > 1)
    {
        std::cout << myQueue2.peek() << ", ";
        myQueue2.pop();
    }
    std::cout << myQueue2.peek() << std::endl;
    myQueue2.pop();
    
    std::cout << std::endl << "Testing copy assignment: " << std::endl;
    std::cout << "Expect: 0, -4, -2, 5, 7, 4, 5, 6, 9" << std::endl;
    std::cout << "   Got: ";
    while (myQueue3.size() > 1)
    {
        std::cout << myQueue3.peek() << ", ";
        myQueue3.pop();
    }
    std::cout << myQueue3.peek() << std::endl;
    myQueue3.pop();
    
    return 0;
}


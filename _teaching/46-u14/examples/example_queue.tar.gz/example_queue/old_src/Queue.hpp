#ifndef QUEUE_H
#define QUEUE_H

#include <cstddef>

class Queue
{
public:
    Queue(int capacity = 16); // Default constructor
    Queue(const Queue &other); // Copy constructor
    Queue &operator=(const Queue &other); // Copy assignment operator
    ~Queue(); // Destructor
    
    // Adds a new object to the back of the queue.
    void push(int value);
    
    // Look at the object at the front of the queue.
    int peek() const;
    
    // Remove the object from the front of the queue.
    void pop();
    
    size_t size() const;
    size_t capacity() const;

private:
    int *m_data;
    size_t m_front;
    size_t m_size;
    size_t m_capacity;
};

#endif


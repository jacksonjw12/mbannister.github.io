#include "Queue.hpp"

#include <algorithm>
#include <cassert>

Queue::Queue(int capacity)
    : m_data(nullptr)
    , m_front(0)
    , m_size(0)
    , m_capacity(capacity)
{
    m_data = new int[m_capacity];
}

Queue::Queue(const Queue &other)
    : m_data(nullptr)
    , m_front(other.m_front)
    , m_size(other.m_size)
    , m_capacity(other.m_capacity)
{
    m_data = new int[m_capacity];
    std::copy(other.m_data, other.m_data + other.m_capacity, m_data);
}

Queue &Queue::operator=(const Queue &other)
{
    if (this != &other)
    {
        m_front = other.m_front;
        m_size = other.m_size;
        m_capacity = other.m_capacity;
        
        delete[] m_data;
        m_data = new int[m_capacity];
        
        std::copy(other.m_data, other.m_data + other.m_capacity, m_data);
    }
    return *this;
}

Queue::~Queue()
{
    delete[] m_data;
    m_data = nullptr;
}

void Queue::push(int value)
{
    assert(m_size <= m_capacity);
    if (m_size == m_capacity)
    {
        size_t newCapacity = m_capacity * 2;
        int *newData = new int[newCapacity];
        std::copy(m_data, m_data + m_front, newData);
        std::copy(m_data + m_front, m_data + m_capacity,
                  newData + m_capacity + m_front);
        delete[] m_data;
        m_data = newData;
        m_front = m_capacity + m_front;
        m_capacity = newCapacity;
    }
    m_data[(m_front + m_size) % m_capacity] = value;
    m_size += 1;
}

int Queue::peek() const
{
    assert(m_size > 0);
    return m_data[m_front];
}

void Queue::pop()
{
    assert(m_size > 0);
    m_front = (m_front + 1) % m_capacity;
    m_size -= 1;
}

size_t Queue::size() const
{
    return m_size;
}

size_t Queue::capacity() const
{
    return m_capacity;
}


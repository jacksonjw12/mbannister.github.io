
#ifndef QUEUE_H
#define QUEUE_H

#include <cstddef>
#include <cassert>
#include <algorithm>

template <typename T>
class Queue
{
public:
	Queue(size_t capacity = 16);
    	Queue(const Queue &other); // Copy constructor
    	Queue &operator=(const Queue &other); // Copy assignment operator
	~Queue();

    	void push(const T &value);
    	T peek() const;
    	void pop();

	size_t size() const;
	size_t capacity() const;

private:
    T *m_data;
    size_t m_front;
    size_t m_size;
    size_t m_capacity;
};

template <typename T>
Queue<T>::Queue(size_t capacity)
    : m_data(nullptr)
    , m_front(0)
    , m_size(0)
    , m_capacity(capacity)
{
    m_data = new T[m_capacity];
}

template <typename T>
Queue<T>::Queue(const Queue<T> &other)
    : m_data(nullptr)
    , m_front(other.m_front)
    , m_size(other.m_size)
    , m_capacity(other.m_capacity)
{
    m_data = new T[m_capacity];
    std::copy(other.m_data, other.m_data + other.m_capacity, m_data);
}

template <typename T>
Queue<T> &Queue<T>::operator=(const Queue<T> &other)
{
    if (this != &other)
    {
        m_front = other.m_front;
        m_size = other.m_size;
        m_capacity = other.m_capacity;
        
        delete[] m_data;
        m_data = new T[m_capacity];
        
        std::copy(other.m_data, other.m_data + other.m_capacity, m_data);
    }
    return *this;
}

template <typename T>
Queue<T>::~Queue()
{
    delete[] m_data;
    m_data = nullptr;
}

template <typename T>
void Queue<T>::push(const T &value)
{
    assert(m_size <= m_capacity);
    if (m_size == m_capacity)
    {
        size_t newCapacity = m_capacity * 2;
        T *newData = new T[newCapacity];
        std::copy(m_data, m_data + m_front, newData);
        std::copy(m_data + m_front, m_data + m_capacity,
                  newData + m_capacity + m_front);
        delete[] m_data;
        m_data = newData;
        m_front = m_capacity + m_front;
        m_capacity = newCapacity;
    }
    m_data[(m_front + m_size) % m_capacity] = value;
    m_size += 1;
}

template <typename T>
T Queue<T>::peek() const
{
    assert(m_size > 0);
    return m_data[m_front];
}

template <typename T>
void Queue<T>::pop()
{
    assert(m_size > 0);
    m_front = (m_front + 1) % m_capacity;
    m_size -= 1;
}

template <typename T>
size_t Queue<T>::size() const
{
    return m_size;
}

template <typename T>
size_t Queue<T>::capacity() const
{
    return m_capacity;
}


#endif



#include "NewQueue.hpp"
#include <iostream>

int main()
{
	Queue<int> myQueue;
	Queue<double> myQueue2;

	myQueue.push(5);
	myQueue.push(6);
	myQueue2.push(10.5);
	myQueue2.push(11.5);

	Queue<double> myQueue3(myQueue2);
	Queue<double> myQueue4;
	myQueue4 = myQueue2;

	std::cout << myQueue.peek() << std::endl;
	myQueue.pop();
	std::cout << myQueue.peek() << std::endl;
	myQueue.pop();

	std::cout << myQueue2.peek() << std::endl;
	myQueue2.pop();
	std::cout << myQueue2.peek() << std::endl;
	myQueue2.pop();

	myQueue2.size();
	myQueue2.capacity();

	return 0;
}

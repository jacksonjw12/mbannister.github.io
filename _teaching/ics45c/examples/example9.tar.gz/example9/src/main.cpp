// This is an example of working with dynamically allocated arrays.
#include <iostream>

void print_array(int A[], int size);
int* range(int size);

int main()
{
    std::cout << "Please enter a number: ";
    int size = 0;
    std::cin >> size;
    
    int *A = range(size);
    print_array(A, size);
    std::cout << std::endl;

    // TODO: Comment out the next line and run with 'make memcheck'
    // to see how to diagnose a memory leak.
    delete[] A;

    return 0;
}

void print_array(int A[], int size)
{
    for (int i = 0; i < size; i++)
    {
        std::cout << A[i] << "  ";
    }
}

int* range(int size)
{
    int *A = new int[size];
    for (int i = 0; i < size; i++) A[i] = i;
    return A;
}


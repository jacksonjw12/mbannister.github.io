#ifndef __CLASSES_HPP__
#define __CLASSES_HPP__

// Since these classes all have very short implementations they have been
// implemented here in the header file.

class A
{
    public:
        A()
        {
            std::cout << "Constructing A (" << this << ")" << std::endl;
        }
        virtual ~A()
        {
            std::cout << "Destructing A (" << this << ")" << std::endl;
        }
};

class B : public A
{
    public:
        B()
        {
            std::cout << "Constructing B (" << this << ")" << std::endl;
        }
        virtual ~B()
        {
            std::cout << "Destructing B (" << this << ")" << std::endl;
        }
};

class C : public A
{
    public:
        C()
        {
            std::cout << "Constructing C (" << this << ")" << std::endl;
        }
        virtual ~C()
        {
            std::cout << "Destructing C (" << this << ")" << std::endl;
        }
};

class D : public A
{
    public:
        D()
        {
            std::cout << "Constructing D (" << this << ")" << std::endl;
        }
        virtual ~D()
        {
            std::cout << "Destructing D (" << this << ")" << std::endl;
        }
};

#endif // __CLASSES_HPP__

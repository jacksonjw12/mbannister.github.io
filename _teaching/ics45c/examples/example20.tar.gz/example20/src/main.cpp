#include <vector>
#include <iostream>
#include <memory>
#include "classes.hpp"

int main()
{
    // By using unique pointer instead of "raw" pointers we can use
    // inheritance without the need to manually call new and delete to
    // manage memory. In general, when a unique pointer goes out of scope
    // the destructor of the object it points to is called and the object
    // is deleted.

    { // Placing a block of code in braces limits the scope of its variables
        std::vector<std::unique_ptr<A>> my_objects;
        my_objects.push_back(std::make_unique<B>());
        my_objects.push_back(std::make_unique<C>());
        my_objects.push_back(std::make_unique<D>());
    }

    // For shared pointers the object pointed to is deleted when there
    // are no longer any pointers pointing to it.
    std::shared_ptr<B> ptr1 = std::make_shared<B>();
    std::cout << ptr1.use_count() << " pointers point to "
              << ptr1.get() << std::endl;

    std::shared_ptr<B> ptr2 = ptr1;
    std::cout << ptr1.use_count() << " pointers point to "
              << ptr1.get() << std::endl;
    
    ptr2 = nullptr;
    std::cout << ptr1.use_count() << " pointers point to "
              << ptr1.get() << std::endl;

    ptr1 = nullptr;
    std::cout << ptr1.use_count() << " pointers point to "
              << ptr1.get() << std::endl;

    // By properly using unique and shared pointers in your code
    // you can eliminated many common memory leaks.

    return 0;
}


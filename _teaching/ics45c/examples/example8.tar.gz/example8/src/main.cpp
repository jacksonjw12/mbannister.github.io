// A simple program that will parse a CSV file and sum each line
// A program is run with:
//   make run < data/input.dat > data/output.dat
#include <iostream>
#include <string>
#include <sstream>

int main()
{
    // Loop through all of the lines
    for (std::string line; std::getline(std::cin, line); )
    {
        std::stringstream line_stream(line);
        int sum = 0;
        // Loop through all of the integers on each line
        for (std::string token; std::getline(line_stream, token, ',');)
        {
            sum += std::stoi(token);
        }
        std::cout << sum << std::endl;
    }

    return 0;
}


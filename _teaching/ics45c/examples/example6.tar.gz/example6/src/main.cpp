// This a quiz of sorts on understanding pass-by-reference and
// pass-by-copy. See if you can predict what the this program will print,
// and then run the program to confirm your predictions.

#include <iostream>


void print(int a, int b, int c);
void swap(int &a, int &b);
void crazy(int &a, int b, int &c);
void insane(int &a, int b, int &c, int d);



int main()
{
    int a = 1;
    int b = 2;
    int c = 3;

    print(a, b, c);
    crazy(a,b,c);
    print(a, b, c);
    crazy(a,b,c);
    print(a, b, c);
    insane(a,b,c,a);
    print(a,b,c);
    insane(a,b,c,c);
    print(a,b,c);

    return 0;
}


void print(int a, int b, int c)
{
    std::cout << "a = " << a << std::endl
              << "b = " << b << std::endl
              << "c = " << c << std::endl << std::endl;
}


void swap(int &a, int &b)
{
    int temp = a;
    a = b;
    b = temp;
}


void crazy(int &a, int b, int &c)
{
    a = b + c;
    b = a + c;
    c = a + b;
    a = b;
    b = c;
    c = a;
    b = a;
}


void insane(int &a, int b, int &c, int d)
{
    a = b + c;
    b = c - a;
    d = b + d;
    c = d + a;
    swap(a, b);
    swap(b, c);
    swap(c, d);
    swap(d, a);
    a = b;
    c = d;
}



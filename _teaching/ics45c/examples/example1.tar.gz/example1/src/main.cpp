// This example program contains some of the functions described in class
// on Jun 27.

#include <iostream>
#include <string>

// Function prototypes
void my_print(int n);
void my_print(std::string msg);
int counter();
int factorial_1(int n);
int factorial_2(int n);
int factorial_2(int n, int a);


// Main function
int main()
{
    my_print(3);
    my_print(10);
    my_print("Test");
    my_print("Hello world");
    std::cout << std::endl << std::endl;

    for (int i = 0; i < 10; i++)
    {
        std::cout << "counter() -> " << counter() << std::endl;
    }
    std::cout << std::endl << std::endl;


    bool valid = false;
    while(!valid)
    {
        std::cout << "Input a number: ";
        int n = 0;
        std::cin >> n;

        if (n < 0)
        {
            std::cout << "Negative numbers not supported." << std::endl;
            continue;
        }
        else if (n > 12)
        {
            std::cout << "Output is too big for 'int' type." << std::endl;
            continue;
        }
        else
        {
            valid = true;
        }


        std::cout << "factorial_1(" << n << ") = "
                  << factorial_1(n) << std::endl;
        std::cout << "factorial_2(" << n << ") = "
                  << factorial_2(n) << std::endl;
    }
    
    return 0;
}


// Function definitions
void my_print(int n)
{
    std::cout << "Integer: " << n << std::endl;
}


void my_print(std::string msg)
{
    std::cout << "String: " << msg << std::endl;
}


int counter()
{
    static int count = 0;
    count++;
    return count;
}


int factorial_1(int n)
{
    if (n <= 0)
    {
        return 1;
    }
    return n * factorial_1(n-1);
}


int factorial_2(int n)
{
    return factorial_2(n, 1);
}


int factorial_2(int n, int a)
{
    if (n <= 0)
    {
        return a;
    }
    return factorial_2(n-1, n * a);
}



// This is a basic example of generating random numbers in C++
#include <iostream>
#include <random>

int main()
{
    // Setting up a random number generator in C++ is a three step
    // process.
    //
    // 1) We create a random_device object through which we will ask the 
    //    operating system for some "true" random data to seed our random
    //    number generator with.
    std::random_device rd;
    // 2) Then we create a random number engine seeded with some "true"
    //    random data. Unless you have a good reason not to, you should
    //    use the default_random_engine.
    std::default_random_engine e(rd());
    // 3) The last step is to create a probability distribution. Here I am
    //    using a uniform distribution of ints between 1 and 10.
    std::uniform_int_distribution<int> uniform(1,10);
    std::cout << "Enter a number: ";
    int c = 0;
    std::cin >> c;
    for (int i = 0; i < c; i++)
    {
        // To actually produce the random number we pass the engine to the
        // distribution.
        std::cout << uniform(e) << std::endl;
    }
    return 0;
}


#include <iostream>
#include <vector>
#include <algorithm>

int main()
{
    std::vector<int> my_vector(5);
    my_vector = {6655, 3223, 1616, 1111, 3233};

    int item1 = 1111;
    int item2 = 2222;

    if ( std::find(my_vector.begin(), my_vector.end(), item1)
            != my_vector.end() )
    {
        std::cout << "contains item1" << std::endl;
    }

    if ( std::find(my_vector.begin(), my_vector.end(), item2)
            != my_vector.end() )
    {
        std::cout << "contains item2" << std::endl;
    }

    return 0;
}


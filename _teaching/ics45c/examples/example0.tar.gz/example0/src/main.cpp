// This example is based on the code from lecture introducing the fundamental
// C++ types and control structures.
#include <iostream>
#include <string>

int main()
{
    std::cout << "Enter your favorite string (spaces are allowed): ";
    std::string msg;
    std::getline(std::cin, msg);
    std::cout << msg << std::endl;
    std::cout << std::endl << std::endl;
    
    // In class we talked about the basic arithmetic types. You can find a
    // complete overview of these types (and more) here:
    //     http://en.cppreference.com/w/cpp/language/types

    std::cout << "Please enter a number, a = ";
    int a = 0;
    std::cin >> a;
    std::cout << "Please enter a number, b = ";
    int b = 0;
    std::cin >> b;
    std::cout << "a + b = " << a + b << std::endl;
    std::cout << "a * b = " << a * b << std::endl;
    std::cout << std::endl << std::endl;

    // C++ gets its name from the increment operator '++'. The following
    // example should illustrate the behavior of this and related operators.

    int i = 10;
    int j = 15;
    std::cout << "int i = " << i << std::endl;
    std::cout << "int j = " << j << std::endl;
    std::cout << "After: j = i++" << std::endl;
    j = i++;
    std::cout << "int i = " << i << std::endl;
    std::cout << "int j = " << j << std::endl;
    std::cout << "After: j = ++i" << std::endl;
    j = ++i;
    std::cout << "int i = " << i << std::endl;
    std::cout << "int j = " << j << std::endl;
    std::cout << "After: j = i--" << std::endl;
    j = i--;
    std::cout << "int i = " << i << std::endl;
    std::cout << "int j = " << j << std::endl;
    std::cout << "After: j = --i" << std::endl;
    j = --i;
    std::cout << "int i = " << i << std::endl;
    std::cout << "int j = " << j << std::endl;
    std::cout << std::endl << std::endl;

    // In general, you should prefer to use the pre-increment (++i) and
    // pre-decrement (--i) operators, as they tend to produce clearer code. 

    // An example of a while loop.
    bool stop = false;
    while (stop == false)
    {
        std::cout << "Please enter a number (or zero to stop): ";
        int k = 0;
        std::cin >> k;
        std::cout << "The square of " << k
                  << " is " << k*k << "." << std::endl;
        if (k == 0)
        {
            stop = true;
        }
    }
    std::cout << std::endl << std::endl;

    // An example of a for loop.
    std::cout << "Please enter a number: ";
    int m = 0;
    std::cin >> m;

    int sum = 0;
    for (int i = 1; i <= m; i++)
    {
        sum = sum + i;
    }
    std::cout << "The sum of the first " << m
              << " numbers is " << sum << std::endl;

    // An example of an infinite loop with a break statement;
    for(;;)
    {
        std::cout << "Please enter an integer between 13 and 56: ";
        int n = 0;
        std::cin >> n;
        if (n < 14)
        {
            std::cout << "Too small! Try again!" << std::endl;
        }
        else if (n > 55)
        {
            std::cout << "Too big! Try again!" << std::endl;
        }
        else
        {
            std::cout << "Good job!!!" << std::endl;
            break;
        }
    }

    return 0;
}


#include "shapes.hpp"



//==== implementations for Shape class =========================================
Shape::Shape(Color color)
    : m_color(color)
{
}

Shape::~Shape()
{
}

const Color& Shape::get_color()
{
    return m_color;
}



//==== implementations for Triangle class ======================================
Triangle::Triangle(Point point1, Point point2, Point point3, Color color)
    : Shape(color)
    , m_point1(point1)
    , m_point2(point2)
    , m_point3(point3)
{
}

Triangle::~Triangle()
{
}

bool right_turn_test(Point p, Point q, Point r)
{
    return (q.x - p.x) * (r.y - p.y) - (q.y - p.y) * (r.x - p.x) <= 0;
}

bool Triangle::contains_point(Point p)
{
    bool test1 = right_turn_test(m_point1, m_point2, p);
    bool test2 = right_turn_test(m_point2, m_point3, p);
    bool test3 = right_turn_test(m_point3, m_point1, p);
    return (test1 == test2) && (test2 == test3) && (test3 == test1);
}



#ifndef __SKIPLISTMAP_HPP__
#define __SKIPLISTMAP_HPP__

#include <vector>
#include <utility>


// Exceptions (empty classes) for SkipListMap methods. You may add extra features
// to these classes, but do not change their names.
class key_not_found{};
class duplicate_key{};
class invalid_level{};


// An enum class to represent the three types of SkipListMapNode.
// Not all Key types will have +- infinity. So we will use an enum
// to represent these values.
enum class SkipListMapNodeType {finite, negative_infinity, positive_infinity};


// A SkipListMapNode from which we can build a SkipListMap
template <typename Key, typename Value>
struct SkipListMapNode
{
    SkipListMapNodeType type;
    Key key;
    Value value;

    SkipListMapNode* up;
    SkipListMapNode* down;
    SkipListMapNode* next;
    SkipListMapNode* prev;
};


// The actual SkipListMap.
// The template parameter Key should be assume to implement only those operators
// absolutely needed for a skiplist.
template <typename Key, typename Value>
class SkipListMap
{
    public:
        // Default constructor: creates an empty SkipListMap
        SkipListMap();
        // Copy constructor: creates a deep-copy of the SkipListMap
        SkipListMap(const SkipListMap& other);
        // Destructor: deallocates all memory associated with the SkipListMap
        ~SkipListMap();
        // Assignment operator: assigns a deep-copy of other to "this"
        SkipListMap& operator=(const SkipListMap& other);

        // Returns the number of key-value pairs stored in the SkipListMap.
        unsigned int size() const;

        // clear() produces an empty SkipListMap
        void clear();
        // insert() takes a key and a value and adds them to the SkipListMap.
        // If the key is already in the SkipListMap, then a duplicate_key
        // exception is thrown.
        void insert(const Key& key, const Value& value);
        // remove() takes a key and removes the corresponding key-value pair.
        // If the key is already in the SkipListMap, then a key_not_cound
        // exception is thrown.
        void remove(const Key& key);
        // contains() returns true if key is in the SkipListMap, and false
        // otherwise.
        bool contains(const Key& key) const;

        // get() returns a constant reference to the value associated with the
        // given key. If the key is not in the SkipListMap, then a key_not_found
        // exception is thrown.
        const Value& get(const Key& key) const;
        // set() changes the value associated with the given key. If the key is
        // not in the SkipListMap, then a key_not_found exception is thrown.
        void set(const Key& key, const Value& value);

        // keys() returns a vector of all key in the SkipListMap in sorted order.
        std::vector<Key> keys() const;
        // items() returns a vector of all key-value pairs in the SkipListMap
        // in sorted order of the keys. 
        std::vector<std::pair<Key, Value>> items() const;
        

        // The following three methods would likely not exist in production code,
        // but will be helpful when debugging your project. You may want to use
        // them to create a method which prints the SkipListMap. Since these
        // methods are for testing you should you straightforward implementations
        // and not worry about speed.

        // height() returns the number of levels in the SkipListMap, counting
        // the empty level at the top of SkipList.
        unsigned int height() const;
        // level_count() returns the number of key-value pairs on a given level.
        // If the level does not exists, an invalid_level exception is thrown.
        unsigned int level_count(unsigned int level) const;
        // key_on_level() returns true if the given key is contained in the
        // given level, and false otherwise. If the level does not exist, an
        // invalid_level exception is thrown.
        bool key_on_level(const Key& key, unsigned int level) const;

    private:
        // Implementation details:
        // 
        // You may add any private variables that you feel you need. 
        //
        // You may also feel free to add additional methods (public or private)
        // you feel you need, but you may not change the signatures of the
        // existing methods.
};

// ==== Implementation =========================================================
// TODO: Implement all of the methods declared in the SkipListMap


#endif // __SKIPLISTMAP_HPP__

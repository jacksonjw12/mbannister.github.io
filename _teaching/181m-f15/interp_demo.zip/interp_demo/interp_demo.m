% This is a short demo on the use of interp2 when applying a projection.
clear all
close all

% Grab and display orginal image.
im = rgb2gray(im2double(imread('gnu.jpg')));
[h w] = size(im)
figure;
imshow(im)

% Define a rotation matrix.
H = [cos(pi/6) -sin(pi/6) 0;
     sin(pi/6)  cos(pi/6) 0;
     0          0         1];

% Use incorrect meshgrid
[X Y] = meshgrid(1:w, 1:h);

% Use correct meshgrid
%[X Y] = meshgrid(-2*w:2*w, -2*h:2*h);


% Apply projection using homogeneous coordinates.
P = cat(2, X(:), Y(:), ones(size(X(:))))';
P_rot = H*P;
X_rot = reshape(P_rot(1,:) ./ P_rot(3,:), size(X));
Y_rot = reshape(P_rot(2,:) ./ P_rot(3,:), size(Y));

% interpolate new image and display
im_rot = interp2(im, X_rot, Y_rot);
figure;
imshow(im_rot)
